inline function getX()
{
	return 2;
}
